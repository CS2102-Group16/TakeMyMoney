local = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'djangostack',
        'HOST': '/Applications/djangostack-1.10.5-0/postgresql',
        'PORT': '5432',
        'USER': 'postgres',
        'PASSWORD': 'root'
    }
}