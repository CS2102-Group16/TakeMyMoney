DROP TABLE sessions;
DROP TABLE funding;
DROP TABLE projects_categories;
DROP TABLE categories;
DROP TABLE projects;
DROP TABLE users;